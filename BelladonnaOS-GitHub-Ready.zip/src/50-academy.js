  // -------------------------
  // TODAY'S LESSON
  // -------------------------

  const belladonnaLessons = [
    {
      title: "Energy Is a Clock",
      level: "Foundation",
      lesson: "Natural energy only helps while it has somewhere to go. Sitting at the cap means the clock is still ticking, but you are getting nothing from it.",
      move: "Before logging off, decide whether that energy belongs in the gym, a chain, or a planned stack."
    },
    {
      title: "A Safe Hit Beats a Glorious Failure",
      level: "Chains",
      lesson: "When the chain timer is low, your job is not to prove anything. Your job is to land a clean hit and keep the chain alive.",
      move: "Keep a few reliable targets ready before the timer becomes everyone’s emergency."
    },
    {
      title: "Travel Profit Is More Than One Trip",
      level: "Money",
      lesson: "The biggest profit number is not always the best route. Time, capacity, cash tied up, and return timing all matter.",
      move: "Compare profit per hour and make sure the trip does not collide with faction activity."
    },
    {
      title: "Do Not Carry a Mugging Invitation",
      level: "Travel",
      lesson: "Returning with valuable items is already noticeable. Returning with unnecessary cash makes the greeting committee more enthusiastic.",
      move: "Secure spare cash before flying and sell with a plan instead of improvising in public."
    },
    {
      title: "Your Cooldowns Are a Schedule",
      level: "Efficiency",
      lesson: "Drug, booster, and medical cooldowns are not just timers. Together they tell you what kind of session you can actually have.",
      move: "Check cooldowns before committing to a chain, happy jump, flight, or training block."
    },
    {
      title: "A Chain Starts Before the First Hit",
      level: "Chains",
      lesson: "Preparation decides whether a chain feels controlled or becomes thirty people asking the same question in Discord.",
      move: "Be in Torn, know the goal, have targets ready, and understand whether you are holding or spending energy."
    },
    {
      title: "Cash Has a Job",
      level: "Money",
      lesson: "Money without a purpose quietly becomes casino money, impulse money, or mugging money. None of those are investment strategies.",
      move: "Give every large amount a job: travel stock, bank investment, gear, education, or a defined savings target."
    },
    {
      title: "Know What You Can Actually Finish",
      level: "Planning",
      lesson: "A plan built around perfect timing, perfect attendance, and nobody making a mistake is not a plan. It is fan fiction.",
      move: "Leave room for missed hits, API delays, travel mistakes, and real life."
    },
    {
      title: "Easy Targets Are Infrastructure",
      level: "Chains",
      lesson: "Reliable targets keep chains alive and allow newer members to contribute. Burning every easy target early removes your safety net.",
      move: "Use targets according to the pace and orders, not simply because they are there."
    },
    {
      title: "Read the Room Before You Fly",
      level: "Faction",
      lesson: "A profitable flight can still be a bad decision when a chain, war push, revive call, or faction event is close.",
      move: "Check the faction schedule and your return time before leaving Torn."
    },
    {
      title: "Public Data Is Not Certainty",
      level: "Recon",
      lesson: "Status, level, faction, and last action can support a decision, but they do not reveal hidden battle stats or guarantee someone is safe.",
      move: "Separate confirmed facts from estimates and never let confidence outrun evidence."
    },
    {
      title: "Notes Beat Memory",
      level: "Recon",
      lesson: "Useful intelligence disappears when it only lives in chat history or someone’s head.",
      move: "Record why a target, trader, or contact matters—and date the note when the information may expire."
    },
    {
      title: "Do Not Spend the Emergency Hit",
      level: "Chains",
      lesson: "Using every available attack while the timer is healthy may leave nobody ready when the timer suddenly drops.",
      move: "Unless orders say otherwise, preserve enough energy for one clean emergency hit."
    },
    {
      title: "The Goal Needs a Pace",
      level: "Planning",
      lesson: "A target number means very little until you know the time available and the hits required per member.",
      move: "Turn the goal into hits per minute and average contribution before declaring it easy."
    },
    {
      title: "A Tool Should Explain Itself",
      level: "Belladonna",
      lesson: "A recommendation is only useful when you can see what caused it. Blind trust is not intelligence; it is delegation with better branding.",
      move: "Check the facts and reasons behind every Oracle recommendation."
    }
  ];

  function getLessonIndexForToday(extra = 0) {
    const today = new Date();
    const dateSeed = Number(
      `${today.getUTCFullYear()}${String(today.getUTCMonth() + 1).padStart(2, "0")}${String(today.getUTCDate()).padStart(2, "0")}`
    );
    return (dateSeed + extra) % belladonnaLessons.length;
  }

  function openTodaysLesson() {
    const body = makePanel(
      "belladonnaLessonPanel",
      "📖 Today's Lesson",
      "One useful thing. No lecture hall. No exam. No excuse."
    );

    body.innerHTML = `
      <div id="lessonContent"></div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:7px;">
        <button id="lessonComplete" style="${sharedButtonStyle}background:#5b244b;border:0;">Mark Complete</button>
        <button id="lessonAnother" style="${sharedButtonStyle}">Show Another</button>
      </div>
      <div id="lessonMessage" style="margin-top:10px;font-size:12px;opacity:.82;"></div>
    `;

    const savedExtra = number(load("lesson:extra", "0"));
    renderLesson(getLessonIndexForToday(savedExtra));

    $("lessonComplete").onclick = markLessonComplete;
    $("lessonAnother").onclick = showAnotherLesson;
  }

  function renderLesson(index) {
    const lesson = belladonnaLessons[index];
    const completed = JSON.parse(load("lesson:completed", "[]"));
    const isComplete = completed.includes(lesson.title);

    $("lessonContent").innerHTML = `
      <div style="${cardStyle}">
        <div style="font-size:11px;opacity:.7;text-transform:uppercase;letter-spacing:.08em;">${lesson.level}</div>
        <h3 style="margin:5px 0 10px;">${lesson.title}</h3>
        <div style="line-height:1.5;">${lesson.lesson}</div>
      </div>

      <div style="${cardStyle}">
        <b>Your move</b><br><br>
        ${lesson.move}
      </div>

      ${isComplete ? `<div style="${cardStyle}"><b>✓ Already completed</b><br>Apparently you do listen. Disturbing, but appreciated.</div>` : ""}
    `;

    save("lesson:currentTitle", lesson.title);
  }

  function markLessonComplete() {
    const title = load("lesson:currentTitle");
    const completed = JSON.parse(load("lesson:completed", "[]"));

    if (title && !completed.includes(title)) completed.push(title);
    save("lesson:completed", JSON.stringify(completed));

    $("lessonMessage").innerHTML = `✓ Lesson recorded. Knowledge has occurred. Nobody make it weird.`;
    renderLesson(belladonnaLessons.findIndex(lesson => lesson.title === title));
  }

  function showAnotherLesson() {
    const nextExtra = number(load("lesson:extra", "0")) + 1;
    save("lesson:extra", nextExtra);
    renderLesson(getLessonIndexForToday(nextExtra));
    $("lessonMessage").innerHTML = "";
  }

