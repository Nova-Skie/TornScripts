  // -------------------------
  // BELLADONNA ORACLE
  // -------------------------

  function openBelladonnaOracle() {
    const body = makePanel(
      "belladonnaOraclePanel",
      "🔮 Belladonna Oracle",
      "It does not predict the future. It notices the present before you waste it."
    );

    body.innerHTML = `
      <label>API Key</label>
      <input id="oracleApiKey" value="${load("apiKey")}" placeholder="Your Torn API key" style="${sharedInputStyle}">

      <label>What are you trying to decide?</label>
      <select id="oracleQuestion" style="${sharedInputStyle}">
        <option value="next">What should I do next?</option>
        <option value="travel">Should I travel?</option>
        <option value="chain">Am I ready for the chain?</option>
        <option value="efficiency">What am I wasting?</option>
      </select>

      <button id="oracleConsult" style="${sharedButtonStyle}background:#5b244b;border:0;">Consult the Oracle</button>

      <div id="oracleOutput" style="font-size:13px;line-height:1.45;margin-top:12px;"></div>
    `;

    $("oracleQuestion").value = load("oracle:question", "next");
    $("oracleConsult").onclick = consultOracle;
  }

  async function consultOracle() {
    const key = $("oracleApiKey").value.trim();
    const question = $("oracleQuestion").value;
    const output = $("oracleOutput");

    if (!key) {
      output.innerHTML = "The Oracle requires an API key. Incense was considered, but the documentation was poor.";
      return;
    }

    save("apiKey", key);
    save("oracle:question", question);
    output.innerHTML = "Gathering the facts. The veil is mostly just several API calls.";

    const state = {
      energy: null,
      maxEnergy: null,
      nerve: null,
      maxNerve: null,
      happy: null,
      maxHappy: null,
      life: null,
      maxLife: null,
      drugCooldown: null,
      boosterCooldown: null,
      medicalCooldown: null,
      travelDestination: "",
      travelTimestamp: null,
      chainCurrent: number(load("chain:current", "0")),
      chainGoal: number(load("chain:goal", chainCommandSettings.defaultGoal)),
      chainTimer: number(load("chain:timer", "0")),
      readiness: load("chain:readiness", "ready"),
      errors: []
    };

    try {
      const bars = await torn("user", "", "bars", key);
      state.energy = bars.energy?.current ?? null;
      state.maxEnergy = bars.energy?.maximum ?? null;
      state.nerve = bars.nerve?.current ?? null;
      state.maxNerve = bars.nerve?.maximum ?? null;
      state.happy = bars.happy?.current ?? null;
      state.maxHappy = bars.happy?.maximum ?? null;
      state.life = bars.life?.current ?? null;
      state.maxLife = bars.life?.maximum ?? null;
    } catch (error) {
      state.errors.push(`Bars: ${error.message}`);
    }

    try {
      const cooldowns = await torn("user", "", "cooldowns", key);
      state.drugCooldown = cooldowns.cooldowns?.drug ?? cooldowns.drug ?? null;
      state.boosterCooldown = cooldowns.cooldowns?.booster ?? cooldowns.booster ?? null;
      state.medicalCooldown = cooldowns.cooldowns?.medical ?? cooldowns.medical ?? null;
    } catch (error) {
      state.errors.push(`Cooldowns: ${error.message}`);
    }

    try {
      const travel = await torn("user", "", "travel", key);
      state.travelDestination = travel.travel?.destination || travel.destination || "";
      state.travelTimestamp = travel.travel?.timestamp || travel.timestamp || null;
    } catch (error) {
      state.errors.push(`Travel: ${error.message}`);
    }

    try {
      const faction = await torn("faction", "", "chain", key);
      const chain = faction.chain || faction;
      if (chain && chain.current !== undefined) {
        state.chainCurrent = number(chain.current);
        state.chainTimer = number(chain.timeout);
        state.chainGoal = Math.max(state.chainGoal, number(chain.max));
        save("chain:current", state.chainCurrent);
        save("chain:timer", state.chainTimer);
      }
    } catch (error) {
      state.errors.push(`Chain: ${error.message}`);
    }

    renderOracleReading(question, state);
  }

  function renderOracleReading(question, state) {
    const output = $("oracleOutput");
    const facts = [];
    const warnings = [];
    const opportunities = [];

    if (state.energy !== null) {
      facts.push(`Energy: ${state.energy}/${state.maxEnergy ?? "?"}`);
      if (state.maxEnergy && state.energy >= state.maxEnergy * 0.9) {
        warnings.push("Your energy is near the cap. Natural regeneration is about to become decorative.");
      } else if (state.energy >= chainCommandSettings.energyPerAttack) {
        opportunities.push(`You have roughly ${Math.floor(state.energy / chainCommandSettings.energyPerAttack)} attacks available.`);
      }
    }

    if (state.nerve !== null) {
      facts.push(`Nerve: ${state.nerve}/${state.maxNerve ?? "?"}`);
      if (state.maxNerve && state.nerve >= state.maxNerve * 0.9) {
        warnings.push("Your nerve is near the cap. Crime does not commit itself, tragically.");
      }
    }

    if (state.happy !== null) facts.push(`Happy: ${state.happy}/${state.maxHappy ?? "?"}`);
    if (state.life !== null) facts.push(`Life: ${state.life}/${state.maxLife ?? "?"}`);

    if (state.drugCooldown !== null) facts.push(`Drug cooldown: ${formatDuration(state.drugCooldown)}`);
    if (state.boosterCooldown !== null) facts.push(`Booster cooldown: ${formatDuration(state.boosterCooldown)}`);
    if (state.medicalCooldown !== null) facts.push(`Medical cooldown: ${formatDuration(state.medicalCooldown)}`);

    const travelling = Boolean(state.travelDestination && !/torn/i.test(state.travelDestination));
    if (state.travelDestination) facts.push(`Travel: ${state.travelDestination}`);

    if (state.chainCurrent > 0) {
      facts.push(`Chain: ${state.chainCurrent}/${state.chainGoal} — ${formatChainTime(state.chainTimer)}`);

      if (state.chainTimer <= 60) {
        warnings.unshift("The chain timer is under one minute.");
      } else if (state.chainTimer <= chainCommandSettings.dangerTimeSeconds) {
        warnings.unshift("The chain timer is in danger.");
      } else if (state.chainTimer <= chainCommandSettings.warningTimeSeconds) {
        warnings.push("The chain timer is below three minutes.");
      }
    }

    let verdict = "";

    if (question === "travel") {
      if (travelling) {
        verdict = `You are already travelling toward ${state.travelDestination}. The decision has escaped containment. Check your return time against the chain and current orders.`;
      } else if (state.chainCurrent > 0 && state.chainTimer <= 300) {
        verdict = "Do not travel. An active chain with a short timer outranks flowers, plushies, and whatever Switzerland is whispering to you.";
      } else if (state.readiness === "ready" && state.chainCurrent > 0) {
        verdict = "Stay in Torn unless faction orders clearly release you. You marked yourself ready, and the chain is active.";
      } else if (state.energy !== null && state.maxEnergy && state.energy >= state.maxEnergy * 0.9) {
        verdict = "Use the energy first, then reconsider travel. Flying at the cap turns regeneration into wasted time.";
      } else {
        verdict = "Travel looks reasonable from the information available. Check the route in Voyage Profit Nerd and compare the return time with faction plans before leaving.";
      }
    } else if (question === "chain") {
      if (travelling) {
        verdict = "You are not chain-ready while abroad. Return timing is now the main problem.";
      } else if (state.chainCurrent <= 0) {
        verdict = "No active chain is showing. Prepare targets and energy, but do not start spending resources based on imaginary urgency.";
      } else if (state.chainTimer <= 60 && state.energy !== null && state.energy >= 25) {
        verdict = "You are ready and the chain is not. Make a safe hit now.";
      } else if (state.chainTimer <= 120 && (state.energy === null || state.energy < 25)) {
        verdict = "The timer is dangerous and you cannot cover a hit with natural energy. Call it out immediately.";
      } else if (state.energy !== null && state.energy >= 25) {
        verdict = `You are in Torn with roughly ${Math.floor(state.energy / 25)} attack(s) available. Keep a safe target ready and follow the current orders.`;
      } else {
        verdict = "You are in Torn, but natural energy is low. Check refills and cooldowns, then stay available rather than silently disappearing.";
      }
    } else if (question === "efficiency") {
      if (warnings.length) {
        verdict = warnings[0] + " Fix that first; the rest can wait.";
      } else if (state.energy !== null && state.energy >= 25) {
        verdict = "Nothing critical is being wasted right now. Your clearest available resource is energy, so give it a deliberate job instead of letting indecision spend it for you.";
      } else {
        verdict = "No major waste is visible from the data available. Check Today’s Lesson or your current goal rather than inventing busywork.";
      }
    } else {
      if (state.chainCurrent > 0 && state.chainTimer <= 60 && state.energy !== null && state.energy >= 25) {
        verdict = "Protect the chain. Make one safe hit now. Everything else has temporarily become background scenery.";
      } else if (state.chainCurrent > 0 && state.chainTimer <= 120) {
        verdict = state.energy !== null && state.energy >= 25
          ? "Make a clean chain hit, then reassess."
          : "Warn the faction that the timer is low. You cannot cover it with natural energy.";
      } else if (travelling) {
        verdict = `You are travelling toward ${state.travelDestination}. Use the downtime to review chain timing, cooldowns, and your next action on landing.`;
      } else if (state.energy !== null && state.maxEnergy && state.energy >= state.maxEnergy * 0.9) {
        verdict = "Use your energy before natural regeneration is wasted. Train unless an active chain or faction order gives it a better job.";
      } else if (state.nerve !== null && state.maxNerve && state.nerve >= state.maxNerve * 0.9) {
        verdict = "Use your nerve. It is near the cap and currently accomplishing nothing except looking full.";
      } else if (state.energy !== null && state.energy >= 25) {
        verdict = "No emergency is showing. Use your available energy deliberately, then check the travel calculator or your current faction orders.";
      } else {
        verdict = "No urgent move is visible. Review Today’s Lesson, update your goals, or step away until a resource or faction need changes.";
      }
    }

    output.innerHTML = `
      <div style="${cardStyle}">
        <div style="font-size:11px;opacity:.7;text-transform:uppercase;letter-spacing:.08em;">Oracle verdict</div>
        <h3 style="margin:6px 0 10px;">${verdict}</h3>
      </div>

      <div style="${cardStyle}">
        <b>Facts used</b><br><br>
        ${facts.length ? facts.map(fact => `• ${fact}`).join("<br>") : "No live facts were available. The Oracle dislikes this nearly as much as you should."}
      </div>

      ${warnings.length ? `
        <div style="${cardStyle}">
          <b>Warnings</b><br><br>
          ${warnings.map(item => `• ${item}`).join("<br>")}
        </div>
      ` : ""}

      ${opportunities.length ? `
        <div style="${cardStyle}">
          <b>Available options</b><br><br>
          ${opportunities.map(item => `• ${item}`).join("<br>")}
        </div>
      ` : ""}

      ${state.errors.length ? `
        <div style="${cardStyle}">
          <b>Information the API withheld</b><br><br>
          ${state.errors.join("<br>")}
          <br><br>
          <span style="opacity:.72;font-size:11px;">The recommendation used what it could verify and ignored what it could not.</span>
        </div>
      ` : ""}

      <div style="opacity:.72;font-size:11px;margin-top:8px;">
        The Oracle recommends. You decide. Blaming a purple button remains legally and spiritually weak.
      </div>
    `;
  }

  function formatDuration(secondsValue) {
    const totalSeconds = Math.max(0, Math.floor(number(secondsValue)));
    if (totalSeconds < 60) return `${totalSeconds}s`;

    const hours = Math.floor(totalSeconds / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);

    if (hours > 0) return `${hours}h ${minutes}m`;
    return `${minutes}m`;
  }


