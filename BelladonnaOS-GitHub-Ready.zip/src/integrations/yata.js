  // -------------------------
  // YATA INTEGRATION ADAPTER
  // -------------------------

  /*
    YATA is optional. Belladonna OS remains fully usable without it.

    The public YATA project confirms that YATA is a separate Torn helper
    service, but its live spy API contract and authentication should be
    configured from current YATA documentation or faction instructions.

    Set BELLADONNA_CONFIG.yata.enabled, baseUrl, and apiKey in app-config.js.
    The adapter deliberately refuses to invent an endpoint.
  */

  function yataIsConfigured() {
    return Boolean(
      BELLADONNA_CONFIG.yata.enabled &&
      BELLADONNA_CONFIG.yata.baseUrl &&
      BELLADONNA_CONFIG.yata.apiKey
    );
  }

  async function yataRequest(path, options = {}) {
    if (!yataIsConfigured()) {
      throw new Error("YATA is not configured. Belladonna is using local intelligence only.");
    }

    const baseUrl = BELLADONNA_CONFIG.yata.baseUrl.replace(/\/+$/, "");
    const cleanPath = String(path || "").replace(/^\/+/, "");
    const url = `${baseUrl}/${cleanPath}`;

    const response = await fetch(url, {
      method: options.method || "GET",
      headers: {
        "Accept": "application/json",
        "Authorization": `Bearer ${BELLADONNA_CONFIG.yata.apiKey}`,
        ...(options.headers || {})
      },
      body: options.body ? JSON.stringify(options.body) : undefined
    });

    if (!response.ok) {
      throw new Error(`YATA request failed with status ${response.status}.`);
    }

    return response.json();
  }

  async function getYataSpyReport(playerId) {
    /*
      Configure the exact route once YATA's current spy endpoint is confirmed.
      Keeping this in one function means the rest of Recon never needs to care
      how YATA names or authenticates the route.
    */
    throw new Error(
      `YATA spy route is not configured for player ${playerId}. Add the current route in src/integrations/yata.js.`
    );
  }

