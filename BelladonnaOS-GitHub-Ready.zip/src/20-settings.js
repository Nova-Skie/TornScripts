  // -------------------------
  // PROFILE & SETTINGS
  // -------------------------

  function openBelladonnaSettings() {
    const body = makePanel(
      "belladonnaSettingsPanel",
      "⚙ Profile & Settings",
      "Tell Belladonna what you are trying to become. Otherwise it guesses, and guessing is how cults start."
    );

    body.innerHTML = `
      <div id="settingsTabs" style="display:grid;grid-template-columns:repeat(4,1fr);gap:5px;margin-bottom:11px;">
        <button data-settings-tab="profile" style="${sharedButtonStyle}padding:8px 3px;font-size:11px;">Profile</button>
        <button data-settings-tab="api" style="${sharedButtonStyle}padding:8px 3px;font-size:11px;">API</button>
        <button data-settings-tab="appearance" style="${sharedButtonStyle}padding:8px 3px;font-size:11px;">Theme</button>
        <button data-settings-tab="data" style="${sharedButtonStyle}padding:8px 3px;font-size:11px;">Data</button>
      </div>
      <div id="settingsContent"></div>
    `;

    body.querySelectorAll("[data-settings-tab]").forEach(button => {
      button.onclick = () => showSettingsTab(button.dataset.settingsTab);
    });

    showSettingsTab("profile");
  }

  function showSettingsTab(tabName) {
    document.querySelectorAll("[data-settings-tab]").forEach(button => {
      button.style.background = button.dataset.settingsTab === tabName ? accentColour() : "#242424";
    });

    if (tabName === "profile") renderProfileSettings();
    if (tabName === "api") renderApiSettings();
    if (tabName === "appearance") renderAppearanceSettings();
    if (tabName === "data") renderDataSettings();
  }

  function renderProfileSettings() {
    const profile = getProfile();
    const content = $("settingsContent");

    content.innerHTML = `
      <label>Display name</label>
      <input id="profileName" value="${profile.displayName}" placeholder="Eshara, preferably. Dave is less ominous." style="${sharedInputStyle}">

      <label>Experience</label>
      <select id="profileExperience" style="${sharedInputStyle}">
        <option value="new">New</option>
        <option value="learning">Learning</option>
        <option value="experienced">Experienced</option>
        <option value="leadership">Leadership</option>
      </select>

      <label>Battle build</label>
      <select id="profileBuild" style="${sharedInputStyle}">
        <option value="balanced">Balanced</option>
        <option value="strength">Strength</option>
        <option value="defense">Defense</option>
        <option value="speed">Speed</option>
        <option value="dexterity">Dexterity</option>
      </select>

      <label>Primary goal</label>
      <select id="profilePrimaryGoal" style="${sharedInputStyle}">
        <option value="general">General growth</option>
        <option value="battle">Battle stats</option>
        <option value="networth">Networth</option>
        <option value="ranked-war">Ranked war</option>
        <option value="crimes">Crimes</option>
        <option value="travel">Travel income</option>
        <option value="job">Job progression</option>
      </select>

      <label>Secondary goal</label>
      <select id="profileSecondaryGoal" style="${sharedInputStyle}">
        <option value="none">None</option>
        <option value="battle">Battle stats</option>
        <option value="networth">Networth</option>
        <option value="ranked-war">Ranked war</option>
        <option value="crimes">Crimes</option>
        <option value="travel">Travel income</option>
        <option value="job">Job progression</option>
      </select>

      <label style="display:block;margin:8px 0;"><input id="profileSafeAttacks" type="checkbox"> Prefer safer attack advice</label>
      <label style="display:block;margin:8px 0;"><input id="profileSaveXanax" type="checkbox"> Save Xanax for chains</label>
      <label style="display:block;margin:8px 0 12px;"><input id="profileTravelWarning" type="checkbox"> Warn me about travelling before chains</label>

      <button id="profileSave" style="${sharedButtonStyle}background:${accentColour()};border:0;">Save Profile</button>
      <div id="profileMessage" style="font-size:12px;opacity:.82;margin-top:10px;"></div>
    `;

    $("profileExperience").value = profile.experience;
    $("profileBuild").value = profile.build;
    $("profilePrimaryGoal").value = profile.primaryGoal;
    $("profileSecondaryGoal").value = profile.secondaryGoal;
    $("profileSafeAttacks").checked = profile.safeAttacks;
    $("profileSaveXanax").checked = profile.saveXanaxForChains;
    $("profileTravelWarning").checked = profile.avoidTravelBeforeChains;

    $("profileSave").onclick = () => {
      writeJson("profile", {
        displayName: $("profileName").value.trim(),
        experience: $("profileExperience").value,
        build: $("profileBuild").value,
        primaryGoal: $("profilePrimaryGoal").value,
        secondaryGoal: $("profileSecondaryGoal").value,
        safeAttacks: $("profileSafeAttacks").checked,
        saveXanaxForChains: $("profileSaveXanax").checked,
        avoidTravelBeforeChains: $("profileTravelWarning").checked
      });

      $("profileMessage").textContent = "Profile saved. Belladonna now has fewer excuses for bad advice.";
    };
  }

  function renderApiSettings() {
    const content = $("settingsContent");

    content.innerHTML = `
      <label>Torn API key</label>
      <input id="settingsApiKey" value="${load("apiKey")}" placeholder="Stored only on this device" style="${sharedInputStyle}">
      <button id="settingsSaveApi" style="${sharedButtonStyle}margin-bottom:7px;">Save API Key</button>
      <button id="settingsTestApi" style="${sharedButtonStyle}background:${accentColour()};border:0;">Run API Health Check</button>
      <div id="apiHealthOutput" style="font-size:13px;line-height:1.45;margin-top:12px;"></div>
    `;

    $("settingsSaveApi").onclick = () => {
      save("apiKey", $("settingsApiKey").value.trim());
      $("apiHealthOutput").innerHTML = `<div style="${cardStyle}">API key saved locally. It has not been sent anywhere else.</div>`;
    };

    $("settingsTestApi").onclick = runApiHealthCheck;
  }

  async function runApiHealthCheck() {
    const key = $("settingsApiKey").value.trim();
    const output = $("apiHealthOutput");

    if (!key) {
      output.innerHTML = "Add a key first. The health check cannot examine a philosophical concept.";
      return;
    }

    save("apiKey", key);
    output.innerHTML = `<div style="${cardStyle}">Testing access. Politely knocking on several doors.</div>`;

    const tests = [
      ["Basic player information", "user", "basic"],
      ["Bars", "user", "bars"],
      ["Money", "user", "money"],
      ["Travel", "user", "travel"],
      ["Cooldowns", "user", "cooldowns"],
      ["Faction chain", "faction", "chain"]
    ];

    const results = [];

    for (const [label, section, selection] of tests) {
      try {
        await torn(section, "", selection, key);
        results.push({ label, okay: true, message: "Available" });
      } catch (error) {
        results.push({ label, okay: false, message: error.message });
      }
    }

    output.innerHTML = `
      <div style="${cardStyle}">
        <b>API health</b><br><br>
        ${results.map(result => `${result.okay ? "✓" : "⚠"} <b>${result.label}</b><br><span style="opacity:.72;font-size:11px;">${result.message}</span><br><br>`).join("")}
      </div>
      <div style="${cardStyle}">
        <b>Recommendation</b><br><br>
        ${results.every(result => result.okay)
          ? "Everything Alpha 1.0 currently uses is available."
          : "Belladonna will use what is available and fall back where possible. Missing access may simply mean the key is restricted."}
      </div>
    `;
  }

  function renderAppearanceSettings() {
    const appearance = getAppearance();
    const content = $("settingsContent");

    content.innerHTML = `
      <label>Accent colour</label>
      <select id="appearanceAccent" style="${sharedInputStyle}">
        <option value="#6e315d">Belladonna Purple</option>
        <option value="#3d5f8f">Night Blue</option>
        <option value="#477c62">Field Green</option>
        <option value="#8b4b3e">Ember</option>
        <option value="#6b6b6b">Steel</option>
      </select>

      <label style="display:block;margin:8px 0 12px;"><input id="appearanceCompact" type="checkbox"> Compact mode</label>
      <button id="appearanceSave" style="${sharedButtonStyle}background:${accentColour()};border:0;">Save Appearance</button>
      <div id="appearanceMessage" style="font-size:12px;opacity:.82;margin-top:10px;"></div>
    `;

    $("appearanceAccent").value = appearance.accent;
    $("appearanceCompact").checked = appearance.compactMode;

    $("appearanceSave").onclick = () => {
      writeJson("appearance", {
        accent: $("appearanceAccent").value,
        compactMode: $("appearanceCompact").checked
      });
      $("appearanceMessage").textContent = "Appearance saved. Reopen Belladonna OS to see it everywhere.";
    };
  }

  function renderDataSettings() {
    const content = $("settingsContent");

    content.innerHTML = `
      <div style="${cardStyle}">
        <b>Local Belladonna data</b><br><br>
        Back up your profile, settings, lessons, coverage, recon notes, chain information, and other local records.
      </div>

      <button id="dataExport" style="${sharedButtonStyle}background:${accentColour()};border:0;margin-bottom:7px;">Export My Belladonna Data</button>
      <label>Import backup</label>
      <textarea id="dataImportText" rows="6" placeholder="Paste a Belladonna OS backup here" style="${sharedInputStyle}resize:vertical;"></textarea>
      <button id="dataImport" style="${sharedButtonStyle}margin-bottom:7px;">Import Backup</button>
      <button id="dataClear" style="${sharedButtonStyle}background:#5f2525;">Clear Belladonna Data</button>
      <div id="dataMessage" style="font-size:12px;opacity:.82;margin-top:10px;"></div>
    `;

    $("dataExport").onclick = exportBelladonnaData;
    $("dataImport").onclick = importBelladonnaData;
    $("dataClear").onclick = clearBelladonnaData;
  }

  async function exportBelladonnaData() {
    const data = {};

    for (let index = 0; index < localStorage.length; index += 1) {
      const key = localStorage.key(index);
      if (key && key.startsWith(`${APP}:`)) data[key] = localStorage.getItem(key);
    }

    const backup = JSON.stringify({
      app: "Belladonna OS",
      version: "Alpha 1.0",
      exportedAt: new Date().toISOString(),
      data
    }, null, 2);

    try {
      await navigator.clipboard.writeText(backup);
      $("dataMessage").textContent = "Backup copied. Store it somewhere less chaotic than Discord chat.";
    } catch (error) {
      $("dataImportText").value = backup;
      $("dataMessage").textContent = "Clipboard access failed, so the backup is in the text box.";
    }
  }

  function importBelladonnaData() {
    try {
      const backup = JSON.parse($("dataImportText").value.trim());
      if (!backup.data || typeof backup.data !== "object") throw new Error("No data block found.");

      Object.entries(backup.data).forEach(([key, value]) => {
        if (key.startsWith(`${APP}:`)) localStorage.setItem(key, value);
      });

      $("dataMessage").textContent = "Backup imported. Belladonna remembers again.";
    } catch (error) {
      $("dataMessage").textContent = `Import failed: ${error.message}`;
    }
  }

  function clearBelladonnaData() {
    const keys = [];

    for (let index = 0; index < localStorage.length; index += 1) {
      const key = localStorage.key(index);
      if (key && key.startsWith(`${APP}:`)) keys.push(key);
    }

    keys.forEach(key => localStorage.removeItem(key));
    $("dataMessage").textContent = "Belladonna data cleared. A clean slate, which is just a blank problem waiting to happen.";
  }


