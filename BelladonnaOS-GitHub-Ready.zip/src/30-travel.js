  // -------------------------
  // TRAVEL CALCULATOR
  // -------------------------

  async function getUserReport(key) {
    const report = {};

    try {
      report.basic = await torn("user", "", "basic", key);
    } catch (error) {
      report.basicError = error.message;
    }

    try {
      report.money = await torn("user", "", "money", key);
    } catch (error) {
      report.moneyError = error.message;
    }

    try {
      report.travel = await torn("user", "", "travel", key);
    } catch (error) {
      report.travelError = error.message;
    }

    return report;
  }

  async function getItemMap(key) {
    const cached = JSON.parse(load("travel:itemMap", "null"));
    const cachedAt = number(load("travel:itemMapAt", "0"));

    if (cached && Date.now() - cachedAt < 24 * 60 * 60 * 1000) {
      return cached;
    }

    const data = await torn("torn", "", "items", key);
    const itemMap = {};

    Object.entries(data.items || {}).forEach(([id, item]) => {
      itemMap[item.name] = { id: Number(id), name: item.name };
    });

    save("travel:itemMap", JSON.stringify(itemMap));
    save("travel:itemMapAt", Date.now());
    return itemMap;
  }

  async function getLowestMarketPrice(itemId, key) {
    const cacheKey = `travel:market:${itemId}`;
    const cached = JSON.parse(load(cacheKey, "null"));

    if (cached && Date.now() - cached.at < 5 * 60 * 1000) {
      return cached.price;
    }

    const url = `${TORN_API}/v2/market/${itemId}/itemmarket?limit=1&offset=0&key=${encodeURIComponent(key)}`;
    const response = await fetch(url);
    const data = await response.json();

    if (data.error) {
      throw new Error(data.error.error || JSON.stringify(data.error));
    }

    const listings = data.itemmarket?.listings || [];
    if (!listings.length) return null;

    const price = number(listings[0].price);
    save(cacheKey, JSON.stringify({ price, at: Date.now() }));
    return price;
  }

  function openTravelCalculator() {
    const body = makePanel(
      "belladonnaTravelPanel",
      "✈ TBN Voyage Profit Nerd",
      "Better information. Fewer terrible decisions. Allegedly."
    );

    body.innerHTML = `
      <label>API Key</label>
      <input id="travelApiKey" value="${load("apiKey")}" placeholder="Your Torn API key" style="${sharedInputStyle}">

      <button id="travelReadUser" style="${sharedButtonStyle}margin-bottom:9px;">Pull Wallet Info</button>

      <label>Cash to spend</label>
      <input id="travelCash" type="number" value="${load("travel:cash")}" placeholder="Pulled from wallet if your key allows it" style="${sharedInputStyle}">

      <label>Flight setup</label>
      <select id="travelFlight" style="${sharedInputStyle}">
        <option value="standard">Standard</option>
        <option value="airstrip">Airstrip / PI</option>
        <option value="business">Business Class</option>
      </select>

      <label>Extra carry capacity</label>
      <input id="travelExtra" type="number" value="${load("travel:extra", "4")}" style="${sharedInputStyle}">

      <button id="travelCalculate" style="${sharedButtonStyle}background:#2f6fed;border:0;">Find Best Route</button>
      <div id="travelOutput" style="font-size:13px;line-height:1.4;margin-top:12px;"></div>
    `;

    $("travelFlight").value = load("travel:flight", "airstrip");
    $("travelReadUser").onclick = handleTravelUserPull;
    $("travelCalculate").onclick = handleTravelCalculation;
  }

  async function handleTravelUserPull() {
    const output = $("travelOutput");
    const key = $("travelApiKey").value.trim();

    if (!key) {
      output.innerHTML = "No key, no magic. This is organized crime, not organized guessing.";
      return;
    }

    save("apiKey", key);
    output.innerHTML = "Checking your wallet. Very respectfully. Mostly.";

    try {
      const report = await getUserReport(key);
      let message = "API key works. Look at us being functional.<br>";

      if (report.basic?.name) message += `Player: <b>${report.basic.name}</b><br>`;

      if (report.money?.money_onhand !== undefined) {
        $("travelCash").value = report.money.money_onhand;
        save("travel:cash", report.money.money_onhand);
        message += `Wallet cash: <b>${money(report.money.money_onhand)}</b><br>`;
      }

      if (report.travel?.destination) {
        message += `Current travel status: ${report.travel.destination}<br>`;
      }

      if (report.moneyError) message += `<br>Wallet access issue: ${report.moneyError}`;
      if (report.travelError) message += `<br>Travel access issue: ${report.travelError}`;

      output.innerHTML = message;
    } catch (error) {
      output.innerHTML = "The API had feelings about that: " + error.message;
    }
  }

  async function handleTravelCalculation() {
    const output = $("travelOutput");
    const key = $("travelApiKey").value.trim();
    const cash = number($("travelCash").value);
    const flightKey = $("travelFlight").value;
    const extra = number($("travelExtra").value);

    if (!key) {
      output.innerHTML = "Add your API key first. I am talented, not psychic.";
      return;
    }

    if (cash <= 0) {
      output.innerHTML = "Add cash to spend. Dreams remain tragically non-liquid.";
      return;
    }

    save("apiKey", key);
    save("travel:cash", cash);
    save("travel:flight", flightKey);
    save("travel:extra", extra);

    const flight = FLIGHTS[flightKey];
    const capacity = flight.capacity + extra;
    output.innerHTML = "Running the numbers because apparently someone had to.";

    try {
      const itemMap = await getItemMap(key);
      const results = [];

      for (const route of ROUTES) {
        for (const itemName of route.items) {
          const item = itemMap[itemName];
          const abroadPrice = ABROAD_PRICES[itemName];
          if (!item || !abroadPrice) continue;

          const marketPrice = await getLowestMarketPrice(item.id, key);
          if (!marketPrice) continue;

          const quantity = Math.min(capacity, Math.floor(cash / abroadPrice));
          if (quantity <= 0) continue;

          const roundTrip = route.minutes * flight.speed * 2;
          const cost = quantity * abroadPrice;
          const revenue = quantity * marketPrice;
          const profit = revenue - cost;
          const profitPerHour = profit / (roundTrip / 60);
          const roi = cost > 0 ? (profit / cost) * 100 : 0;

          results.push({
            country: route.country,
            itemName,
            abroadPrice,
            marketPrice,
            quantity,
            roundTrip,
            profit,
            profitPerHour,
            roi
          });
        }
      }

      results.sort((a, b) => b.profitPerHour - a.profitPerHour);

      if (!results.length) {
        output.innerHTML = "No profitable route found. Rare. Suspicious. Deeply inconvenient.";
        return;
      }

      const best = results[0];

      output.innerHTML = `
        <div style="${cardStyle}">
          <b>Best Route: ${best.country}</b><br>
          Buy: <b>${best.quantity} × ${best.itemName}</b><br>
          Abroad cost: ${money(best.abroadPrice)} each<br>
          Market price: ${money(best.marketPrice)} each<br>
          Profit: <b>${money(best.profit)}</b><br>
          Profit/hr: <b>${money(best.profitPerHour)}</b><br>
          Round trip: ${Math.round(best.roundTrip)} min<br>
          ROI: ${best.roi.toFixed(1)}%
        </div>

        ${results.slice(0, 10).map((result, index) => `
          <div style="border-bottom:1px solid #333;padding:8px 0;">
            <b>${index + 1}. ${result.country}</b> — ${result.itemName}<br>
            Qty ${result.quantity} | Profit ${money(result.profit)} | ${money(result.profitPerHour)}/hr
          </div>
        `).join("")}

        <div style="opacity:.75;margin-top:10px;">
          This recommends. It does not click, buy, sell, travel, or save you from yourself.
        </div>
      `;
    } catch (error) {
      output.innerHTML = "Something broke. Very rude of it: " + error.message;
    }
  }

