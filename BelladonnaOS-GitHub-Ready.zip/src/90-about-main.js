  // -------------------------
  // ABOUT
  // -------------------------

  function openAboutPanel() {
    const body = makePanel(
      "belladonnaPlaceholderPanel",
      "⚙ Belladonna Tools",
      "One interface. Several questionable decisions prevented."
    );

    body.innerHTML = `
      <div style="${cardStyle}">
        <b>Belladonna OS Alpha 1.0</b><br><br>

        Alpha 1.0 foundation:<br>
        • Home Dashboard<br>
        • Player Profile & Goals<br>
        • API Health Check<br>
        • Appearance Settings<br>
        • Local Data Backup & Restore<br>
        • TBN Voyage Profit Nerd<br>
        • Chain Command<br>
        • Academy<br>
        • Faction Coverage<br>
        • Recon Scanner<br>
        • Belladonna Oracle<br><br>

        The script uses your own Torn API key and stores it locally on your device.
        It does not upload your key to Belladonna, Discord, GitHub, a mysterious warehouse,
        or anything else with ambitions.<br><br>

        It calculates, organizes, and recommends. It does not click, attack, travel, buy,
        sell, train, or play Torn for you.<br><br>

        More rooms are being built. Please ignore the noise from the basement.<br><br>

        — <b>Eshara</b>
      </div>
    `;
  }

  createLauncher();
})();
