  // -------------------------
  // FACTION COVERAGE
  // -------------------------

  const coverageStarterData = factionMembersToCoverageText();

  function openFactionCoverage() {
    const body = makePanel(
      "belladonnaCoveragePanel",
      "🌐 Faction Coverage",
      "See when Belladonna is awake, when it is thin, and when everyone has apparently agreed to vanish."
    );

    const savedData = load("coverage:data", coverageStarterData);

    body.innerHTML = `
      <div style="${cardStyle}">
        <b>Manual faction roster</b><br>
        <span style="opacity:.78;font-size:12px;">
          One member per line: Name | UTC offset | local active hours | roles. This stays on this device.
        </span>
      </div>

      <textarea id="coverageData" rows="9" style="${sharedInputStyle}resize:vertical;">${savedData}</textarea>

      <div style="display:grid;grid-template-columns:1fr 1fr;gap:7px;">
        <button id="coverageBuild" style="${sharedButtonStyle}background:#5b244b;border:0;">Build Coverage Map</button>
        <button id="coverageSave" style="${sharedButtonStyle}">Save Roster</button>
      </div>

      <div id="coverageOutput" style="font-size:13px;line-height:1.45;margin-top:12px;"></div>
    `;

    $("coverageBuild").onclick = buildCoverageMap;
    $("coverageSave").onclick = () => {
      save("coverage:data", $("coverageData").value);
      $("coverageOutput").innerHTML = `<div style="${cardStyle}">Roster saved locally. The spreadsheet has been contained.</div>`;
    };
  }

  function parseCoverageRoster(rawData) {
    const members = [];
    const errors = [];

    rawData.split("\n").forEach((rawLine, lineIndex) => {
      const line = rawLine.trim();
      if (!line || line.startsWith("#")) return;

      const parts = line.split("|").map(part => part.trim());
      if (parts.length < 3) {
        errors.push(`Line ${lineIndex + 1}: missing fields`);
        return;
      }

      const name = parts[0];
      const utcOffset = Number(parts[1]);
      const ranges = parts[2].split(",").map(range => range.trim()).filter(Boolean);
      const roles = (parts[3] || "").split(",").map(role => role.trim()).filter(Boolean);

      if (!name || Number.isNaN(utcOffset) || !ranges.length) {
        errors.push(`Line ${lineIndex + 1}: invalid name, offset, or hours`);
        return;
      }

      const activeRanges = [];

      ranges.forEach(range => {
        const match = range.match(/^(\d{1,2})(?::(\d{2}))?-(\d{1,2})(?::(\d{2}))?$/);
        if (!match) {
          errors.push(`Line ${lineIndex + 1}: could not read "${range}"`);
          return;
        }

        const start = Number(match[1]) + Number(match[2] || 0) / 60;
        const end = Number(match[3]) + Number(match[4] || 0) / 60;

        if (start >= 24 || end > 24) {
          errors.push(`Line ${lineIndex + 1}: hours must use 00:00-24:00`);
          return;
        }

        activeRanges.push({ start, end });
      });

      if (activeRanges.length) members.push({ name, utcOffset, activeRanges, roles });
    });

    return { members, errors };
  }

  function isMemberActiveAtTornHour(member, tornHour) {
    const localHour = ((tornHour + member.utcOffset) % 24 + 24) % 24;

    return member.activeRanges.some(range => {
      if (range.start === range.end) return true;
      if (range.end > range.start) return localHour >= range.start && localHour < range.end;
      return localHour >= range.start || localHour < range.end;
    });
  }

  function buildCoverageMap() {
    const rawData = $("coverageData").value;
    const { members, errors } = parseCoverageRoster(rawData);
    const output = $("coverageOutput");

    save("coverage:data", rawData);

    if (!members.length) {
      output.innerHTML = `
        <div style="${cardStyle}">
          <b>No usable members yet.</b><br><br>
          Add lines using this format:<br>
          Eshara | -4 | 18:00-23:30 | Chain Support, Leadership
        </div>
        ${errors.length ? `<div style="${cardStyle}">${errors.join("<br>")}</div>` : ""}
      `;
      return;
    }

    const coverage = Array.from({ length: 24 }, (_, hour) => {
      const activeMembers = members.filter(member => isMemberActiveAtTornHour(member, hour));
      return { hour, activeMembers };
    });

    const currentTornHour = new Date().getUTCHours();
    const maximumCoverage = Math.max(...coverage.map(slot => slot.activeMembers.length), 1);
    const weakHours = coverage.filter(slot => slot.activeMembers.length <= Math.max(1, Math.floor(members.length * 0.2)));

    output.innerHTML = `
      <div style="${cardStyle}">
        <b>Coverage summary</b><br>
        Members mapped: ${members.length}<br>
        Current Torn hour: ${String(currentTornHour).padStart(2, "0")}:00<br>
        Weakest coverage: ${Math.min(...coverage.map(slot => slot.activeMembers.length))} member(s)<br>
        Strongest coverage: ${maximumCoverage} member(s)
      </div>

      <div style="${cardStyle}">
        ${coverage.map(slot => {
          const width = Math.max(3, (slot.activeMembers.length / maximumCoverage) * 100);
          const isCurrent = slot.hour === currentTornHour;
          const names = slot.activeMembers.map(member => member.name).join(", ") || "Nobody expected";
          return `
            <div style="margin-bottom:8px;${isCurrent ? "padding:6px;border:1px solid #7c3f69;border-radius:8px;" : ""}">
              <div style="display:flex;justify-content:space-between;gap:8px;font-size:12px;">
                <b>${String(slot.hour).padStart(2, "0")}:00 TT${isCurrent ? " ← now" : ""}</b>
                <span>${slot.activeMembers.length}</span>
              </div>
              <div style="height:8px;background:#333;border-radius:999px;overflow:hidden;margin:4px 0;">
                <div style="height:100%;width:${width}%;background:${slot.activeMembers.length <= 1 ? "#9d3d3d" : slot.activeMembers.length < maximumCoverage / 2 ? "#a46a2a" : "#477c62"};"></div>
              </div>
              <div style="opacity:.7;font-size:10px;">${names}</div>
            </div>
          `;
        }).join("")}
      </div>

      <div style="${cardStyle}">
        <b>Thin windows</b><br><br>
        ${weakHours.map(slot => `${String(slot.hour).padStart(2, "0")}:00 TT — ${slot.activeMembers.length} expected`).join("<br>")}
      </div>

      ${errors.length ? `<div style="${cardStyle}"><b>Lines I could not read</b><br><br>${errors.join("<br>")}</div>` : ""}
    `;
  }

