  // -------------------------
  // HOME DASHBOARD
  // -------------------------

  function openBelladonnaHome() {
    const profile = getProfile();
    const body = makePanel(
      "belladonnaHomePanel",
      "☠ Belladonna OS",
      "Intelligence, operations, and an unreasonable refusal to waste good information."
    );

    body.innerHTML = `
      <div style="${cardStyle}">
        <div style="font-size:11px;opacity:.72;text-transform:uppercase;letter-spacing:.08em;">Alpha 1.0</div>
        <h2 style="margin:6px 0;">Welcome back, ${profile.displayName || "Operator"}.</h2>
        <div style="opacity:.8;">Let us see what Torn is trying to make your problem today.</div>
      </div>

      <button id="homeRefresh" style="${sharedButtonStyle}background:${accentColour()};border:0;margin-bottom:10px;">Refresh Dashboard</button>
      <div id="homeLiveStatus"><div style="${cardStyle}">Dashboard waiting. Suspiciously calm.</div></div>

      <div style="display:grid;grid-template-columns:1fr 1fr;gap:7px;">
        <button data-home-open="oracle" style="${sharedButtonStyle}">🔮 Oracle</button>
        <button data-home-open="chain" style="${sharedButtonStyle}">⛓ Chain</button>
        <button data-home-open="travel" style="${sharedButtonStyle}">✈ Travel</button>
        <button data-home-open="recon" style="${sharedButtonStyle}">🔍 Recon</button>
        <button data-home-open="lesson" style="${sharedButtonStyle}">📖 Academy</button>
        <button data-home-open="settings" style="${sharedButtonStyle}">⚙ Settings</button>
      </div>
    `;

    $("homeRefresh").onclick = refreshHomeDashboard;

    body.querySelectorAll("[data-home-open]").forEach(button => {
      button.onclick = () => {
        const target = button.dataset.homeOpen;
        if (target === "oracle") openBelladonnaOracle();
        if (target === "chain") openChainCommand();
        if (target === "travel") openTravelCalculator();
        if (target === "recon") openReconScanner();
        if (target === "lesson") openTodaysLesson();
        if (target === "settings") openBelladonnaSettings();
      };
    });

    refreshHomeDashboard();
  }

  async function refreshHomeDashboard() {
    const output = $("homeLiveStatus");
    const key = load("apiKey");
    const profile = getProfile();

    if (!key) {
      output.innerHTML = `<div style="${cardStyle}"><b>Setup needed</b><br><br>Add your Torn API key in Profile & Settings. Authentication remains stubbornly non-mystical.</div>`;
      return;
    }

    output.innerHTML = `<div style="${cardStyle}">Reading the room. The room is mostly API endpoints.</div>`;

    const state = { bars: null, travel: null, chain: null, cooldowns: null, errors: [] };

    try { state.bars = await torn("user", "", "bars", key); } catch (error) { state.errors.push("Bars unavailable"); }
    try { state.travel = await torn("user", "", "travel", key); } catch (error) { state.errors.push("Travel unavailable"); }
    try { const faction = await torn("faction", "", "chain", key); state.chain = faction.chain || faction; } catch (error) { state.errors.push("Chain unavailable"); }
    try { const cooldowns = await torn("user", "", "cooldowns", key); state.cooldowns = cooldowns.cooldowns || cooldowns; } catch (error) { state.errors.push("Cooldowns unavailable"); }

    const energy = state.bars?.energy?.current ?? null;
    const maxEnergy = state.bars?.energy?.maximum ?? null;
    const nerve = state.bars?.nerve?.current ?? null;
    const maxNerve = state.bars?.nerve?.maximum ?? null;
    const destination = state.travel?.travel?.destination || state.travel?.destination || "Torn";
    const energyPercent = energy !== null && maxEnergy ? (energy / maxEnergy) * 100 : 0;
    const nervePercent = nerve !== null && maxNerve ? (nerve / maxNerve) * 100 : 0;

    let priority = "No urgent issue detected. A rare and beautiful administrative miracle.";

    if (state.chain?.current > 0 && number(state.chain.timeout) <= 120 && energy >= 25) {
      priority = "Active chain, low timer, enough energy. Make one safe hit before everyone discovers caps lock.";
    } else if (energyPercent >= 90) {
      priority = profile.saveXanaxForChains && state.chain?.current > 0
        ? "Energy is near the cap, but your profile says to preserve resources for chains. Check orders first."
        : "Energy is near the cap. Train or attack before natural regeneration becomes decorative.";
    } else if (nervePercent >= 90) {
      priority = "Nerve is nearly full. Use it before crime becomes an entirely theoretical hobby.";
    }

    output.innerHTML = `
      <div style="${cardStyle}">
        <div style="font-size:11px;opacity:.72;text-transform:uppercase;letter-spacing:.08em;">Current priority</div>
        <h3 style="margin:6px 0;">${priority}</h3>
      </div>

      <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;">
        <div style="${cardStyle}"><b>Energy</b><br>${energy !== null ? `${energy}/${maxEnergy ?? "?"}` : "Unavailable"}</div>
        <div style="${cardStyle}"><b>Nerve</b><br>${nerve !== null ? `${nerve}/${maxNerve ?? "?"}` : "Unavailable"}</div>
        <div style="${cardStyle}"><b>Chain</b><br>${state.chain?.current > 0 ? `${state.chain.current} — ${formatChainTime(state.chain.timeout)}` : "Inactive"}</div>
        <div style="${cardStyle}"><b>Location</b><br>${destination}</div>
      </div>

      <div style="${cardStyle}">
        <b>Profile focus</b><br>
        Build: ${profile.build}<br>
        Main goal: ${profile.primaryGoal}<br>
        Experience: ${profile.experience}
      </div>

      ${state.errors.length ? `<div style="${cardStyle}"><b>Partial data</b><br><br>${state.errors.join("<br>")}</div>` : ""}
    `;
  }

