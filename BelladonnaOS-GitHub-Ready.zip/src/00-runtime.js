// ==UserScript==
// @name         Belladonna OS
// @version      1.0.0-alpha
// @description  Belladonna OS Alpha 1.0: dashboard, intelligence, operations, profile, settings, and the Oracle.
// @match        *://*.torn.com/*
// @match        *://torn.com/*
// @run-at       document-end
// @grant        none
// ==/UserScript==

(function () {
  "use strict";

  /*
    Belladonna Tools

    Uses the player's own Torn API key.
    Stores settings locally on the player's device.
    Reads permitted information from Torn's official API.
    Calculates, organizes, and recommends. It does not play Torn for you.

    Better information is fair play. Automation is where things get stupid.

    - Eshara
  */

  const APP = "belladonnaOS";
  const TORN_API = "https://api.torn.com";

  const $ = id => document.getElementById(id);
  const save = (key, value) => localStorage.setItem(`${APP}:${key}`, String(value));
  const load = (key, fallback = "") => localStorage.getItem(`${APP}:${key}`) ?? fallback;
  const money = value => "$" + Math.round(Number(value || 0)).toLocaleString();
  const number = value => Math.max(0, Number(value || 0));

  function readJson(key, fallback) {
    try {
      return JSON.parse(load(key, JSON.stringify(fallback)));
    } catch (error) {
      return fallback;
    }
  }

  function writeJson(key, value) {
    save(key, JSON.stringify(value));
  }

  const defaultProfile = {
    displayName: "",
    experience: "learning",
    build: "balanced",
    primaryGoal: "general",
    secondaryGoal: "none",
    safeAttacks: true,
    saveXanaxForChains: true,
    avoidTravelBeforeChains: true
  };

  const defaultAppearance = {
    accent: "#6e315d",
    compactMode: false
  };

  const getProfile = () => ({ ...defaultProfile, ...readJson("profile", defaultProfile) });
  const getAppearance = () => ({ ...defaultAppearance, ...readJson("appearance", defaultAppearance) });
  const accentColour = () => getAppearance().accent || defaultAppearance.accent;

  const sharedButtonStyle = `
    width:100%;
    box-sizing:border-box;
    padding:10px;
    border-radius:10px;
    border:1px solid #555;
    background:#242424;
    color:#fff;
    font-weight:700;
  `;

  const sharedInputStyle = `
    width:100%;
    box-sizing:border-box;
    margin:4px 0 9px;
    padding:9px;
    border-radius:8px;
    background:#222;
    color:#fff;
    border:1px solid #555;
  `;

  const cardStyle = `
    padding:11px;
    border:1px solid #444;
    border-radius:12px;
    background:#1b1b1b;
    margin-bottom:10px;
  `;

  const FLIGHTS = {
    standard: { label: "Standard", speed: 1.0, capacity: 5 },
    airstrip: { label: "Airstrip / PI", speed: 0.7, capacity: 15 },
    business: { label: "Business Class", speed: 0.3, capacity: 15 }
  };

  const ABROAD_PRICES = {
    "Jaguar Plushie": 10000,
    "Dahlia": 300,
    "Stingray Plushie": 400,
    "Banana Orchid": 4000,
    "Wolverine Plushie": 30,
    "Crocus": 600,
    "Orchid": 700,
    "Nessie Plushie": 200,
    "Heather": 5000,
    "Red Fox Plushie": 1000,
    "Monkey Plushie": 400,
    "Ceibo Flower": 500,
    "Edelweiss": 900,
    "Chamois Plushie": 400,
    "Cherry Blossom": 500,
    "Panda Plushie": 400,
    "Peony": 5000,
    "Camel Plushie": 14000,
    "Tribulus Omanense": 6000,
    "Lion Plushie": 400,
    "African Violet": 2000
  };

  const ROUTES = [
    { country: "Mexico", items: ["Jaguar Plushie", "Dahlia"], minutes: 18 },
    { country: "Cayman Islands", items: ["Stingray Plushie", "Banana Orchid"], minutes: 25 },
    { country: "Canada", items: ["Wolverine Plushie", "Crocus"], minutes: 29 },
    { country: "Hawaii", items: ["Orchid"], minutes: 94 },
    { country: "United Kingdom", items: ["Nessie Plushie", "Heather", "Red Fox Plushie"], minutes: 111 },
    { country: "Argentina", items: ["Monkey Plushie", "Ceibo Flower"], minutes: 117 },
    { country: "Switzerland", items: ["Edelweiss", "Chamois Plushie"], minutes: 123 },
    { country: "Japan", items: ["Cherry Blossom"], minutes: 158 },
    { country: "China", items: ["Panda Plushie", "Peony"], minutes: 169 },
    { country: "UAE", items: ["Camel Plushie", "Tribulus Omanense"], minutes: 190 },
    { country: "South Africa", items: ["Lion Plushie", "African Violet"], minutes: 208 }
  ];

  const chainCommandSettings = {
    defaultGoal: 250,
    energyPerAttack: 25,
    warningTimeSeconds: 180,
    dangerTimeSeconds: 120,
    defaultOrders: [
      "Keep the chain moving. Easy targets are there for a reason.",
      "Call it out early if the timer starts getting ugly.",
      "Do not wander off on a scenic international tour during a push."
    ]
  };

  async function torn(section, id, selections, key) {
    const url = `${TORN_API}/${section}/${id || ""}?selections=${encodeURIComponent(selections)}&key=${encodeURIComponent(key)}`;
    const response = await fetch(url);
    const data = await response.json();

    if (data.error) {
      throw new Error(data.error.error || JSON.stringify(data.error));
    }

    return data;
  }

  function closeOpenPanels() {
    ["belladonnaHomePanel", "belladonnaTravelPanel", "belladonnaChainPanel", "belladonnaLessonPanel", "belladonnaCoveragePanel", "belladonnaReconPanel", "belladonnaOraclePanel", "belladonnaSettingsPanel", "belladonnaPlaceholderPanel"].forEach(id => {
      const panel = $(id);
      if (panel) panel.remove();
    });
  }

  function createLauncher() {
    if ($("belladonnaLauncher")) return;

    const launcher = document.createElement("div");
    launcher.id = "belladonnaLauncher";

    Object.assign(launcher.style, {
      position: "fixed",
      right: "12px",
      bottom: "46px",
      zIndex: "999999",
      display: "flex",
      flexDirection: "column",
      alignItems: "flex-end",
      gap: "8px",
      fontFamily: "Arial, sans-serif"
    });

    launcher.innerHTML = `
      <div id="belladonnaToolMenu" style="display:none;flex-direction:column;gap:7px;align-items:flex-end;">
        <button class="belladonnaToolButton" data-tool="home">☠ Home Dashboard</button>
        <button class="belladonnaToolButton" data-tool="oracle">🔮 Belladonna Oracle</button>
        <button class="belladonnaToolButton" data-tool="chain">⛓ Chain Command</button>
        <button class="belladonnaToolButton" data-tool="travel">✈ Travel Calculator</button>
        <button class="belladonnaToolButton" data-tool="recon">🔍 Recon Scanner</button>
        <button class="belladonnaToolButton" data-tool="coverage">🌐 Faction Coverage</button>
        <button class="belladonnaToolButton" data-tool="lesson">📖 Academy</button>
        <button class="belladonnaToolButton" data-tool="settings">⚙ Profile & Settings</button>
        <button class="belladonnaToolButton" data-tool="about">ⓘ About</button>
      </div>

      <button id="belladonnaLauncherButton" style="
        min-width:62px;
        height:44px;
        padding:0 13px;
        border-radius:16px;
        border:1px solid #666;
        background:#151515;
        color:#fff;
        font-weight:800;
        font-size:13px;
        box-shadow:0 3px 12px rgba(0,0,0,.45);
      ">☠ B-OS</button>
    `;

    document.body.appendChild(launcher);

    launcher.querySelectorAll(".belladonnaToolButton").forEach(button => {
      Object.assign(button.style, {
        minWidth: "190px",
        padding: "10px 13px",
        borderRadius: "12px",
        border: "1px solid #555",
        background: "#191919",
        color: "#fff",
        fontWeight: "700",
        fontSize: "13px",
        textAlign: "left",
        boxShadow: "0 3px 10px rgba(0,0,0,.4)"
      });

      button.onclick = () => {
        const tool = button.dataset.tool;
        closeToolMenu();

        if (tool === "home") return openBelladonnaHome();
        if (tool === "travel") return openTravelCalculator();
        if (tool === "chain") return openChainCommand();
        if (tool === "lesson") return openTodaysLesson();
        if (tool === "coverage") return openFactionCoverage();
        if (tool === "recon") return openReconScanner();
        if (tool === "oracle") return openBelladonnaOracle();
        if (tool === "settings") return openBelladonnaSettings();
        if (tool === "about") return openAboutPanel();
      };
    });

    $("belladonnaLauncherButton").onclick = toggleToolMenu;
  }

  function toggleToolMenu() {
    const menu = $("belladonnaToolMenu");
    const button = $("belladonnaLauncherButton");
    const isOpen = menu.style.display === "flex";

    menu.style.display = isOpen ? "none" : "flex";
    button.textContent = isOpen ? "☠ B-OS" : "✕ Close";
  }

  function closeToolMenu() {
    const menu = $("belladonnaToolMenu");
    const button = $("belladonnaLauncherButton");

    if (menu) menu.style.display = "none";
    if (button) button.textContent = "☠ B-OS";
  }

  function makePanel(id, title, subtitle) {
    closeOpenPanels();

    const panel = document.createElement("div");
    panel.id = id;

    Object.assign(panel.style, {
      position: "fixed",
      left: "10px",
      right: "10px",
      bottom: "98px",
      zIndex: "999999",
      maxHeight: "74vh",
      overflowY: "auto",
      background: "#101010",
      color: "#fff",
      border: "1px solid #444",
      borderRadius: "16px",
      padding: "14px",
      fontFamily: "Arial, sans-serif",
      boxShadow: "0 4px 18px rgba(0,0,0,.55)"
    });

    panel.innerHTML = `
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px;">
        <b>${title}</b>
        <button data-close-panel style="background:#333;color:white;border:0;border-radius:8px;padding:6px 10px;">X</button>
      </div>
      <div style="opacity:.82;font-size:12px;margin-bottom:12px;">${subtitle}</div>
      <div data-panel-body></div>
    `;

    document.body.appendChild(panel);
    panel.querySelector("[data-close-panel]").onclick = () => panel.remove();

    return panel.querySelector("[data-panel-body]");
  }

  function openPlaceholderPanel(title, message) {
    const body = makePanel("belladonnaPlaceholderPanel", title, "Belladonna is expanding. Apparently nobody thought to stop us.");
    body.innerHTML = `<div style="${cardStyle}">${message}</div>`;
  }


