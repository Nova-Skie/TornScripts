  // -------------------------
  // CHAIN COMMAND
  // -------------------------

  function openChainCommand() {
    const body = makePanel(
      "belladonnaChainPanel",
      "⛓ Chain Command",
      "Know the chain. Know your place in it. Try not to be the reason everyone starts yelling."
    );

    body.innerHTML = `
      <div id="chainTabs" style="display:grid;grid-template-columns:repeat(4,1fr);gap:5px;margin-bottom:11px;">
        <button data-chain-tab="overview" style="${sharedButtonStyle}padding:8px 3px;font-size:11px;">Overview</button>
        <button data-chain-tab="planning" style="${sharedButtonStyle}padding:8px 3px;font-size:11px;">Planning</button>
        <button data-chain-tab="readiness" style="${sharedButtonStyle}padding:8px 3px;font-size:11px;">Readiness</button>
        <button data-chain-tab="orders" style="${sharedButtonStyle}padding:8px 3px;font-size:11px;">Orders</button>
      </div>
      <div id="chainContent"></div>
    `;

    body.querySelectorAll("[data-chain-tab]").forEach(button => {
      button.onclick = () => showChainTab(button.dataset.chainTab);
    });

    showChainTab("overview");
  }

  function showChainTab(tabName) {
    const content = $("chainContent");
    if (!content) return;

    document.querySelectorAll("[data-chain-tab]").forEach(button => {
      button.style.background = button.dataset.chainTab === tabName ? accentColour() : "#242424";
    });

    if (tabName === "overview") renderChainOverview();
    if (tabName === "planning") renderChainPlanning();
    if (tabName === "readiness") renderChainReadiness();
    if (tabName === "orders") renderChainOrders();
  }

  function renderChainOverview() {
    const content = $("chainContent");

    content.innerHTML = `
      <label>API Key</label>
      <input id="chainApiKey" value="${load("apiKey")}" placeholder="Your Torn API key" style="${sharedInputStyle}">

      <button id="chainPullLive" style="${sharedButtonStyle}background:#5b244b;border:0;margin-bottom:10px;">
        Pull Live Chain Status
      </button>

      <div style="${cardStyle}">
        <b>Manual fallback</b><br>
        <span style="opacity:.78;font-size:12px;">
          If faction API access refuses to cooperate, enter the numbers yourself. We adapt. We complain, but we adapt.
        </span>
      </div>

      <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;">
        <div>
          <label>Current chain</label>
          <input id="chainCurrent" type="number" value="${load("chain:current", "0")}" style="${sharedInputStyle}">
        </div>
        <div>
          <label>Chain goal</label>
          <input id="chainGoal" type="number" value="${load("chain:goal", chainCommandSettings.defaultGoal)}" style="${sharedInputStyle}">
        </div>
        <div>
          <label>Timer seconds</label>
          <input id="chainTimer" type="number" value="${load("chain:timer", "300")}" style="${sharedInputStyle}">
        </div>
        <div>
          <label>Your energy</label>
          <input id="chainEnergy" type="number" value="${load("chain:energy", "0")}" style="${sharedInputStyle}">
        </div>
      </div>

      <button id="chainAnalyze" style="${sharedButtonStyle}">Analyze What We Have</button>
      <div id="chainOverviewOutput" style="font-size:13px;line-height:1.45;margin-top:12px;"></div>
    `;

    $("chainPullLive").onclick = pullLiveChainStatus;
    $("chainAnalyze").onclick = analyzeManualChain;
  }

  async function pullLiveChainStatus() {
    const output = $("chainOverviewOutput");
    const key = $("chainApiKey").value.trim();

    if (!key) {
      output.innerHTML = "Add your API key first. Chain Command has many talents. Telepathy remains unfunded.";
      return;
    }

    save("apiKey", key);
    output.innerHTML = "Pulling the chain status. Nobody touch anything important.";

    const liveReport = {
      chain: null,
      bars: null,
      chainError: "",
      barsError: ""
    };

    try {
      const factionData = await torn("faction", "", "chain", key);
      liveReport.chain = factionData.chain || factionData;
    } catch (error) {
      liveReport.chainError = error.message;
    }

    try {
      const userData = await torn("user", "", "bars", key);
      liveReport.bars = userData;
    } catch (error) {
      liveReport.barsError = error.message;
    }

    if (liveReport.chain) {
      const chain = liveReport.chain;
      const currentChain = number(chain.current);
      const timerSeconds = number(chain.timeout);
      const chainMax = number(chain.max);

      $("chainCurrent").value = currentChain;
      $("chainTimer").value = timerSeconds;

      save("chain:current", currentChain);
      save("chain:timer", timerSeconds);

      if (chainMax > number($("chainGoal").value)) {
        $("chainGoal").value = chainMax;
        save("chain:goal", chainMax);
      }
    }

    const energy = liveReport.bars?.energy?.current;
    if (energy !== undefined) {
      $("chainEnergy").value = energy;
      save("chain:energy", energy);
    }

    if (!liveReport.chain && !liveReport.bars) {
      output.innerHTML = `
        <div style="${cardStyle}">
          <b>The API gave us nothing useful.</b><br><br>
          Chain: ${liveReport.chainError || "Unavailable"}<br>
          Energy: ${liveReport.barsError || "Unavailable"}<br><br>
          Use the manual fields below. Not elegant, but neither is getting mugged in Switzerland.
        </div>
      `;
      return;
    }

    analyzeManualChain();

    const notes = [];
    if (liveReport.chainError) notes.push(`Chain access: ${liveReport.chainError}`);
    if (liveReport.barsError) notes.push(`Energy access: ${liveReport.barsError}`);

    if (notes.length) {
      output.innerHTML += `<div style="opacity:.72;margin-top:8px;">Partial API access: ${notes.join(" | ")}</div>`;
    }
  }

  function analyzeManualChain() {
    const currentChain = number($("chainCurrent").value);
    const chainGoal = Math.max(1, number($("chainGoal").value));
    const timerSeconds = number($("chainTimer").value);
    const yourEnergy = number($("chainEnergy").value);

    save("chain:current", currentChain);
    save("chain:goal", chainGoal);
    save("chain:timer", timerSeconds);
    save("chain:energy", yourEnergy);

    const hitsStillNeeded = Math.max(0, chainGoal - currentChain);
    const expectedHits = Math.floor(yourEnergy / chainCommandSettings.energyPerAttack);
    const chainHealth = getChainHealth(timerSeconds, currentChain);
    const advice = getChainAdvice({
      currentChain,
      chainGoal,
      timerSeconds,
      yourEnergy,
      expectedHits,
      hitsStillNeeded
    });

    const progressPercent = Math.min(100, (currentChain / chainGoal) * 100);
    const output = $("chainOverviewOutput");

    output.innerHTML = `
      <div style="${cardStyle}">
        <div style="display:flex;justify-content:space-between;gap:10px;">
          <div><b>Chain</b><br>${currentChain.toLocaleString()} / ${chainGoal.toLocaleString()}</div>
          <div><b>Timer</b><br>${formatChainTime(timerSeconds)}</div>
          <div><b>Status</b><br>${chainHealth.label}</div>
        </div>

        <div style="height:10px;background:#333;border-radius:999px;overflow:hidden;margin:12px 0 6px;">
          <div style="height:100%;width:${progressPercent}%;background:${chainHealth.bar};"></div>
        </div>
        <div style="opacity:.75;font-size:11px;">${progressPercent.toFixed(1)}% of the selected goal</div>
      </div>

      <div style="${cardStyle}">
        <b>Your position</b><br>
        Energy: ${yourEnergy}<br>
        Estimated attacks: <b>${expectedHits}</b><br>
        Hits still needed: <b>${hitsStillNeeded}</b>
      </div>

      <div style="${cardStyle}">
        <b>Belladonna recommendation</b><br><br>
        ${advice}
      </div>
    `;
  }

  function getChainHealth(timerSeconds, currentChain) {
    if (currentChain <= 0) {
      return { label: "Quiet", bar: "#666", tone: "No active chain detected." };
    }

    if (timerSeconds <= chainCommandSettings.dangerTimeSeconds) {
      return { label: "DANGER", bar: "#b3261e", tone: "The timer is getting ugly." };
    }

    if (timerSeconds <= chainCommandSettings.warningTimeSeconds) {
      return { label: "Warning", bar: "#b86b16", tone: "Someone should hit something soon." };
    }

    return { label: "Healthy", bar: "#3f8f62", tone: "The chain is breathing normally." };
  }

  function getChainAdvice(chainState) {
    const {
      currentChain,
      chainGoal,
      timerSeconds,
      yourEnergy,
      expectedHits,
      hitsStillNeeded
    } = chainState;

    if (currentChain <= 0) {
      if (yourEnergy >= 100) {
        return "No active chain is showing. Your energy is getting high, though, so decide whether you're training or waiting for orders before natural regeneration starts going to waste.";
      }

      return "No active chain is showing. Nothing is on fire. Enjoy this deeply suspicious moment of peace.";
    }

    if (hitsStillNeeded <= 0) {
      return "The selected goal is complete. Nicely done. Check faction orders before spending anything else; leadership may be extending the chain.";
    }

    if (timerSeconds <= 60) {
      return "<b>This is no longer a planning exercise. Hit something.</b>";
    }

    if (timerSeconds <= chainCommandSettings.dangerTimeSeconds) {
      if (expectedHits > 0) {
        return "The timer is under two minutes and you have energy. Make a safe hit now. Heroics are how people end up staring at a failed attack screen while everyone else screams.";
      }

      return "The timer is under two minutes and you do not have enough natural energy for a hit. Call it out immediately so someone who can act actually does.";
    }

    if (timerSeconds <= chainCommandSettings.warningTimeSeconds) {
      if (expectedHits > 0) {
        return "The timer is slipping. Make one clean hit, then reassess. We need movement, not interpretive violence.";
      }

      return "The timer is below three minutes. You cannot cover it right now, so warn the faction instead of silently watching the clock die.";
    }

    if (expectedHits >= 5 && hitsStillNeeded > 20) {
      return `You have roughly ${expectedHits} attacks available. The chain is healthy, so do not dump everything without a reason. Make a hit, keep some energy in reserve, and follow the current orders.`;
    }

    if (expectedHits > 0) {
      return "The chain is healthy and you can contribute. Make a clean hit when the pace needs it, then keep enough energy available in case the timer suddenly develops a personality.";
    }

    return "The chain is healthy, but you do not currently have enough energy for an attack. Stay aware, check your refill and cooldown options, and do not pretend you did not see the timer.";
  }

  function formatChainTime(totalSeconds) {
    const seconds = Math.max(0, Math.floor(number(totalSeconds)));
    const minutes = Math.floor(seconds / 60);
    const leftoverSeconds = seconds % 60;
    return `${minutes}:${String(leftoverSeconds).padStart(2, "0")}`;
  }

  function renderChainPlanning() {
    const content = $("chainContent");

    content.innerHTML = `
      <div style="${cardStyle}">
        <b>Chain planner</b><br>
        <span style="opacity:.78;font-size:12px;">
          This tells us what the goal requires. It cannot make people stop flying five minutes before a chain.
        </span>
      </div>

      <label>Current chain</label>
      <input id="planCurrent" type="number" value="${load("chain:current", "0")}" style="${sharedInputStyle}">

      <label>Target</label>
      <input id="planGoal" type="number" value="${load("chain:goal", chainCommandSettings.defaultGoal)}" style="${sharedInputStyle}">

      <label>Minutes available</label>
      <input id="planMinutes" type="number" value="${load("chain:planMinutes", "60")}" style="${sharedInputStyle}">

      <label>Members expected to hit</label>
      <input id="planMembers" type="number" value="${load("chain:planMembers", "10")}" style="${sharedInputStyle}">

      <button id="planCalculate" style="${sharedButtonStyle}background:#5b244b;border:0;">Calculate the Pace</button>
      <div id="planOutput" style="font-size:13px;line-height:1.45;margin-top:12px;"></div>
    `;

    $("planCalculate").onclick = calculateChainPlan;
  }

  function calculateChainPlan() {
    const currentChain = number($("planCurrent").value);
    const chainGoal = Math.max(1, number($("planGoal").value));
    const minutesAvailable = Math.max(1, number($("planMinutes").value));
    const membersExpected = Math.max(1, number($("planMembers").value));

    save("chain:current", currentChain);
    save("chain:goal", chainGoal);
    save("chain:planMinutes", minutesAvailable);
    save("chain:planMembers", membersExpected);

    const hitsStillNeeded = Math.max(0, chainGoal - currentChain);
    const factionHitsPerMinute = hitsStillNeeded / minutesAvailable;
    const minutesPerFactionHit = hitsStillNeeded > 0 ? minutesAvailable / hitsStillNeeded : 0;
    const hitsPerMember = hitsStillNeeded / membersExpected;
    const energyPerMember = hitsPerMember * chainCommandSettings.energyPerAttack;

    let verdict = "";

    if (hitsStillNeeded === 0) {
      verdict = "Goal already reached. Either celebrate or discover that leadership has quietly moved the finish line.";
    } else if (factionHitsPerMinute >= 2) {
      verdict = "Aggressive pace. Possible with a coordinated push, but this is not the time for people to vanish into the casino.";
    } else if (factionHitsPerMinute >= 0.75) {
      verdict = "Solid working pace. Very manageable if the expected members actually exist outside the spreadsheet.";
    } else {
      verdict = "Comfortable pace. Keep it moving and avoid the classic mistake of relaxing until the timer starts screaming.";
    }

    $("planOutput").innerHTML = `
      <div style="${cardStyle}">
        <b>Hits needed:</b> ${Math.ceil(hitsStillNeeded)}<br>
        <b>Faction pace:</b> ${factionHitsPerMinute.toFixed(2)} hits/minute<br>
        <b>Average gap:</b> ${minutesPerFactionHit.toFixed(2)} minutes per hit<br>
        <b>Average per member:</b> ${hitsPerMember.toFixed(1)} hits<br>
        <b>Energy per member:</b> about ${Math.ceil(energyPerMember)}
      </div>
      <div style="${cardStyle}"><b>Assessment</b><br><br>${verdict}</div>
    `;
  }

  function renderChainReadiness() {
    const content = $("chainContent");
    const currentReadiness = load("chain:readiness", "ready");
    const availableLater = load("chain:availableLater", "");

    content.innerHTML = `
      <div style="${cardStyle}">
        <b>My readiness</b><br>
        <span style="opacity:.78;font-size:12px;">
          Stored only on this device for now. Later, the bot can collect it without us rebuilding the room.
        </span>
      </div>

      <label>Status</label>
      <select id="readinessStatus" style="${sharedInputStyle}">
        <option value="ready">Ready</option>
        <option value="travelling">Travelling</option>
        <option value="busy">Busy</option>
        <option value="later">Available later</option>
        <option value="unavailable">Unavailable</option>
      </select>

      <label>Available later / note</label>
      <input id="readinessLater" value="${availableLater}" placeholder="Example: Back by 21:00 TT" style="${sharedInputStyle}">

      <button id="saveReadiness" style="${sharedButtonStyle}background:#5b244b;border:0;">Save My Status</button>
      <div id="readinessOutput" style="font-size:13px;line-height:1.45;margin-top:12px;"></div>
    `;

    $("readinessStatus").value = currentReadiness;
    $("saveReadiness").onclick = saveReadinessStatus;
  }

  function saveReadinessStatus() {
    const readinessStatus = $("readinessStatus").value;
    const availableLater = $("readinessLater").value.trim();

    save("chain:readiness", readinessStatus);
    save("chain:availableLater", availableLater);

    const statusLabels = {
      ready: "Ready",
      travelling: "Travelling",
      busy: "Busy",
      later: "Available later",
      unavailable: "Unavailable"
    };

    $("readinessOutput").innerHTML = `
      <div style="${cardStyle}">
        <b>Status saved:</b> ${statusLabels[readinessStatus]}<br>
        ${availableLater ? `<b>Note:</b> ${availableLater}<br>` : ""}
        <br>
        This stays on your device for now. Private, useful, and unable to gossip.
      </div>
    `;
  }

  function renderChainOrders() {
    const content = $("chainContent");
    const savedOrders = load("chain:orders", chainCommandSettings.defaultOrders.join("\n"));

    content.innerHTML = `
      <div style="${cardStyle}">
        <b>Faction orders</b><br>
        <span style="opacity:.78;font-size:12px;">
          Manual for now. Paste the current orders here and every part of Chain Command can reference the same instructions.
        </span>
      </div>

      <textarea id="chainOrdersText" rows="7" style="${sharedInputStyle}resize:vertical;">${savedOrders}</textarea>

      <button id="saveChainOrders" style="${sharedButtonStyle}background:#5b244b;border:0;">Save Orders</button>
      <button id="resetChainOrders" style="${sharedButtonStyle}margin-top:7px;">Reset to Defaults</button>

      <div id="ordersOutput" style="font-size:13px;line-height:1.45;margin-top:12px;"></div>
    `;

    $("saveChainOrders").onclick = saveChainOrders;
    $("resetChainOrders").onclick = resetChainOrders;
    showSavedOrders();
  }

  function saveChainOrders() {
    const orders = $("chainOrdersText").value.trim();

    if (!orders) {
      $("ordersOutput").innerHTML = "No orders entered. Anarchy is technically a management style, but not a good one.";
      return;
    }

    save("chain:orders", orders);
    showSavedOrders("Orders saved. The faction may now ignore them with greater accuracy.");
  }

  function resetChainOrders() {
    const defaults = chainCommandSettings.defaultOrders.join("\n");
    $("chainOrdersText").value = defaults;
    save("chain:orders", defaults);
    showSavedOrders("Defaults restored.");
  }

  function showSavedOrders(message = "") {
    const orders = load("chain:orders", chainCommandSettings.defaultOrders.join("\n"));
    const lines = orders.split("\n").map(line => line.trim()).filter(Boolean);

    $("ordersOutput").innerHTML = `
      ${message ? `<div style="margin-bottom:8px;opacity:.85;">${message}</div>` : ""}
      <div style="${cardStyle}">
        <b>Current orders</b><br><br>
        ${lines.map(line => `• ${line}`).join("<br>")}
      </div>
    `;
  }


