  // -------------------------
  // RECON SCANNER
  // -------------------------

  function findPlayerIdOnPage() {
    const url = new URL(window.location.href);
    const queryId = url.searchParams.get("XID") || url.searchParams.get("user2ID") || url.searchParams.get("ID");

    if (queryId && /^\d+$/.test(queryId)) return queryId;

    const pathMatch = window.location.pathname.match(/profiles\/(\d+)/i);
    return pathMatch ? pathMatch[1] : "";
  }

  function openReconScanner() {
    const body = makePanel(
      "belladonnaReconPanel",
      "🔍 Recon Scanner",
      "Facts first. Estimates second. Wild confidence never."
    );

    const detectedPlayerId = findPlayerIdOnPage();

    body.innerHTML = `
      <label>API Key</label>
      <input id="reconApiKey" value="${load("apiKey")}" placeholder="Your Torn API key" style="${sharedInputStyle}">

      <label>Player ID</label>
      <input id="reconPlayerId" value="${detectedPlayerId}" placeholder="Open a profile or enter an ID" inputmode="numeric" style="${sharedInputStyle}">

      <button id="reconScan" style="${sharedButtonStyle}background:#5b244b;border:0;">Scan Public Profile</button>

      <div id="reconOutput" style="font-size:13px;line-height:1.45;margin-top:12px;"></div>
    `;

    $("reconScan").onclick = runReconScan;
  }

  async function runReconScan() {
    const key = $("reconApiKey").value.trim();
    const playerId = $("reconPlayerId").value.trim();
    const output = $("reconOutput");

    if (!key) {
      output.innerHTML = "Add your API key. Recon without information is just staring.";
      return;
    }

    if (!/^\d+$/.test(playerId)) {
      output.innerHTML = "Enter a valid Torn player ID. Numbers only; dramatic aliases can wait.";
      return;
    }

    save("apiKey", key);
    output.innerHTML = "Reading what Torn is willing to tell us. Nothing hidden, nothing invented.";

    try {
      const data = await torn("user", playerId, "basic,profile", key);
      renderReconReport(playerId, data);
    } catch (firstError) {
      try {
        const data = await torn("user", playerId, "profile", key);
        renderReconReport(playerId, data);
      } catch (secondError) {
        output.innerHTML = `
          <div style="${cardStyle}">
            <b>Recon failed.</b><br><br>
            ${secondError.message || firstError.message}<br><br>
            The ID may be wrong, the key may lack public access, or Torn may simply be having a moment.
          </div>
        `;
      }
    }
  }

  function renderReconReport(playerId, data) {
    const output = $("reconOutput");
    const notesKey = `recon:notes:${playerId}`;
    const savedNotes = load(notesKey, "");

    const playerName = data.name || data.player_name || `Player ${playerId}`;
    const level = data.level ?? "Unknown";
    const factionName = data.faction?.faction_name || data.faction?.name || data.faction_name || "No faction shown";
    const statusDescription = data.status?.description || data.status?.state || data.status || "Unknown";
    const lastAction = data.last_action?.relative || data.last_action?.status || data.last_action || "Not provided";
    const age = data.age ?? "Unknown";
    const rank = data.rank || "Unknown";

    const observations = [];

    if (/okay/i.test(String(statusDescription))) observations.push("Currently appears attackable.");
    if (/hospital/i.test(String(statusDescription))) observations.push("Currently in hospital.");
    if (/travel|abroad|flying/i.test(String(statusDescription))) observations.push("Currently away from Torn or travelling.");
    if (/online/i.test(String(lastAction))) observations.push("Recent activity is showing.");
    if (!observations.length) observations.push("No strong tactical conclusion from the public data alone.");

    output.innerHTML = `
      <div style="${cardStyle}">
        <div style="font-size:11px;opacity:.7;text-transform:uppercase;letter-spacing:.08em;">Confirmed public information</div>
        <h3 style="margin:5px 0;">${playerName} [${playerId}]</h3>
        Level: ${level}<br>
        Rank: ${rank}<br>
        Age: ${age} days<br>
        Faction: ${factionName}<br>
        Status: ${typeof statusDescription === "object" ? JSON.stringify(statusDescription) : statusDescription}<br>
        Last action: ${typeof lastAction === "object" ? JSON.stringify(lastAction) : lastAction}
      </div>

      <div style="${cardStyle}">
        <b>Observations</b><br><br>
        ${observations.map(note => `• ${note}`).join("<br>")}
        <br><br>
        <span style="opacity:.72;font-size:11px;">
          These are observations, not hidden-stat claims. Belladonna does not put a tactical hat on a guess and call it intelligence.
        </span>
      </div>

      <label>Private notes for this player</label>
      <textarea id="reconNotes" rows="5" style="${sharedInputStyle}resize:vertical;" placeholder="Trusted trader, war target notes, known habits, date-sensitive observations...">${savedNotes}</textarea>

      <div style="display:grid;grid-template-columns:1fr 1fr;gap:7px;">
        <button id="reconSaveNotes" style="${sharedButtonStyle}background:#5b244b;border:0;">Save Notes</button>
        <button id="reconCopyReport" style="${sharedButtonStyle}">Copy Report</button>
      </div>

      <div id="reconMessage" style="font-size:12px;opacity:.8;margin-top:10px;"></div>
    `;

    $("reconSaveNotes").onclick = () => {
      save(notesKey, $("reconNotes").value.trim());
      $("reconMessage").textContent = "Notes saved locally. Quietly. As notes should be.";
    };

    $("reconCopyReport").onclick = async () => {
      const report = [
        `Belladonna Recon — ${playerName} [${playerId}]`,
        `Level: ${level}`,
        `Rank: ${rank}`,
        `Faction: ${factionName}`,
        `Status: ${typeof statusDescription === "object" ? JSON.stringify(statusDescription) : statusDescription}`,
        `Last action: ${typeof lastAction === "object" ? JSON.stringify(lastAction) : lastAction}`,
        "",
        "Observations:",
        ...observations.map(note => `- ${note}`),
        "",
        `Notes: ${$("reconNotes").value.trim() || "None"}`
      ].join("\n");

      try {
        await navigator.clipboard.writeText(report);
        $("reconMessage").textContent = "Report copied. Try to look appropriately mysterious.";
      } catch (error) {
        $("reconMessage").textContent = "Clipboard access failed. Torn PDA may be protecting the world from our formatting.";
      }
    };
  }

