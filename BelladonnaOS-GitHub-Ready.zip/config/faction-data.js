  /*
    Manual faction coverage data.

    utcOffset:
      Difference from Torn Time / UTC.
      Ontario during daylight time is -4.
      Pakistan is +5.

    activeHours:
      Local member time, 24-hour format.
      Multiple windows are allowed.

    Add or remove members here, then rebuild the project.
  */
  const BELLADONNA_FACTION_MEMBERS = [
    {
      name: "Eshara",
      tornId: "",
      utcOffset: -4,
      activeHours: ["18:00-23:30"],
      roles: ["Leadership", "Chain Support"],
      notes: "Example entry. Replace with the final faction roster."
    }
  ];

  function factionMembersToCoverageText() {
    const heading = [
      "# Generated from config/faction-data.js",
      "# Format: Name | UTC offset | active hours | roles"
    ];

    const rows = BELLADONNA_FACTION_MEMBERS.map(member => {
      const hours = (member.activeHours || []).join(", ");
      const roles = (member.roles || []).join(", ");
      return `${member.name} | ${member.utcOffset} | ${hours} | ${roles}`;
    });

    return [...heading, ...rows].join("\n");
  }

