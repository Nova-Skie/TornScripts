  // Belladonna OS application settings.
  // These values are safe to edit before building a release.
  const BELLADONNA_CONFIG = {
    appName: "Belladonna OS",
    releaseName: "Standalone Alpha",
    factionName: "Belladonna",
    tornApiBase: "https://api.torn.com",
    yata: {
      enabled: false,
      baseUrl: "",
      apiKey: ""
    }
  };

