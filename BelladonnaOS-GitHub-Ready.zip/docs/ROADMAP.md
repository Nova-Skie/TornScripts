# Belladonna OS Roadmap

## Alpha 1.0 — Foundation

- Standalone Torn PDA userscript
- Home dashboard
- Player profile and goals
- API health check
- Appearance settings
- Local data backup and restore
- Existing modules migrated

## Alpha 1.1 — Oracle 2.0

- Shared player-state collector
- Priority recommendation engine
- Daily briefing
- Training adviser
- Attack adviser
- Crime adviser
- Job adviser
- Money adviser
- Goal-aware recommendations

## Alpha 1.2 — Recon Intelligence

- Local intelligence database
- Richer public Torn data
- Manual spy reports
- Attack history
- Target tags
- Threat and confidence ratings
- Spy freshness
- YATA adapter completion after API verification

## Alpha 1.3 — Faction Operations

- Final faction roster data
- Coverage heat map
- Role coverage
- Readiness view
- Chain launch recommendations
- Leadership configuration

## Beta 1

- UI polish
- Faster shared API cache
- Import/export improvements
- Documentation
- Public test release
- Update and version strategy
