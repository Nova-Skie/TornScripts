# Standalone Architecture

Belladonna OS is intentionally offline-first and server-optional.

## Runtime boundaries

- Torn API: official read-only game data
- Torn PDA: script host and local storage
- Local configuration: faction roster, active windows, roles, notes
- YATA: optional external spy source through a single adapter
- Discord bot/server: not required and not referenced by the runtime

## Data ownership

Faction and player notes remain local unless the user deliberately exports them.
API keys must never be placed in committed source files.

## Future expansion

Additional integrations belong in `src/integrations/`.
Each integration should expose a small normalized interface so Recon and Oracle
do not become dependent on one outside service.
