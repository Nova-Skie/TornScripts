# Belladonna OS Ideas

This file is the parking lot for ideas that are worth keeping but are not yet ready for production.

## Intelligence and Oracle

- Priority-ranked daily briefing
- Gym and training adviser
- Attack adviser using Recon intelligence
- Job progression adviser
- Crime and nerve adviser
- Money and networth adviser
- Travel timing adviser
- Goal-sensitive recommendations
- Confidence and reason shown for every recommendation
- Personal routines and reminders
- Long-term progress trends

## Recon and Intelligence

- Local player intelligence database
- Manual and imported spy reports
- Spy freshness warnings
- YATA integration
- TornStats integration if permitted
- Attack history against scanned players
- Target tags and threat ratings
- Faction target lists
- Friendly trader and ally records
- Known muggers, scammers, revivers, and enemies
- Intelligence import and export

## Chain Command

- Member readiness overview
- Shared faction orders
- Chain history and statistics
- Target management
- Contribution coaching
- Estimated chain completion window
- Coverage-aware chain launch recommendation
- War and chain role assignments

## Faction Operations

- Time-zone heat map
- Expected online coverage
- Role coverage
- Weak-hour alerts
- Faction member profiles
- War-room dashboard
- Ranked-war preparation checklist
- Leadership notes
- Training and onboarding modules

## Travel

- Trip history
- Profit history
- Return-time planner
- Airport timer
- Travel journal
- Route alerts
- Faction-event conflict warnings

## Academy

- Larger lesson library
- Beginner, intermediate, and advanced tracks
- Faction-specific SOPs
- Leadership-published lessons
- Progress tracking
- Short quizzes
- Recommended lesson based on current activity

## Platform

- Automatic GitHub release builds
- Optional update checker
- Belladonna logo and visual identity
- Website documentation
- Optional server and bot integration later
- Shared Belladonna core package
- Importable faction configuration packs

## Wild Ideas

- Belladonna Timeline
- Personal Torn efficiency score
- Daily operations report
- Faction launch-window predictor
- War preparation score
- Personal target book
- Offline encrypted intelligence backup
