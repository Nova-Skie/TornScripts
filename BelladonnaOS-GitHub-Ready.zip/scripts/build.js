const fs = require("fs");
const path = require("path");

const root = path.resolve(__dirname, "..");
const outputDir = path.join(root, "dist");

const sourceFiles = [
  "src/00-runtime.js",
  "config/app-config.js",
  "config/faction-data.js",
  "src/integrations/yata.js",
  "src/10-dashboard.js",
  "src/20-settings.js",
  "src/30-travel.js",
  "src/40-chain.js",
  "src/50-academy.js",
  "src/60-coverage.js",
  "src/70-recon.js",
  "src/80-oracle.js",
  "src/90-about-main.js"
];

fs.mkdirSync(outputDir, { recursive: true });

const source = sourceFiles
  .map(relativePath => {
    const absolutePath = path.join(root, relativePath);
    if (!fs.existsSync(absolutePath)) {
      throw new Error(`Missing source file: ${relativePath}`);
    }
    return fs.readFileSync(absolutePath, "utf8").trimEnd();
  })
  .join("\n\n") + "\n";

const userScriptPath = path.join(outputDir, "Belladonna-OS.user.js");
fs.writeFileSync(userScriptPath, source, "utf8");

const versionMatch = source.match(/\/\/ @version\s+([^\n]+)/);
const version = versionMatch ? versionMatch[1].trim() : "development";

const tornPdaPackage = [
  {
    enabled: true,
    matches: [
      "*://*.torn.com/*",
      "*://torn.com/*"
    ],
    name: "Belladonna OS",
    version,
    edited: false,
    source,
    url: null,
    updateStatus: "noRemote",
    isExample: false,
    time: "end",
    customApiKey: "",
    customApiKeyCandidate: false,
    grants: ["none"],
    requires: []
  }
];

const jsonPath = path.join(outputDir, "Belladonna-OS.json");
fs.writeFileSync(jsonPath, JSON.stringify(tornPdaPackage, null, 2), "utf8");

console.log(`Built ${path.relative(root, userScriptPath)}`);
console.log(`Built ${path.relative(root, jsonPath)}`);
